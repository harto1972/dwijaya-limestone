import React from 'react';

export default function DwijayaLimestoneLandingPage() {
  return (
    <div className="min-h-screen bg-stone-100 text-stone-800 font-sans">
      <section className="text-center py-20 bg-stone-200">
        <h1 className="text-4xl font-bold mb-4">Dwijaya Limestone</h1>
        <p className="text-lg mb-6">Pot Bunga Premium dari Resin dan Limestone</p>
        <a
          href="#products"
          className="px-6 py-3 bg-stone-800 text-white rounded-full hover:bg-stone-700"
        >
          Lihat Koleksi
        </a>
      </section>

      <section className="max-w-4xl mx-auto py-16 px-4 text-center">
        <h2 className="text-3xl font-semibold mb-4">Keunggulan Produk Kami</h2>
        <p className="text-stone-600 mb-6">
          Pot bunga kami dibuat dari kombinasi resin dan batu kapur pilihan, menghasilkan produk yang kuat, tahan lama, namun tetap ringan dan elegan. Cocok untuk dekorasi indoor maupun outdoor.
        </p>
      </section>

      <section id="products" className="max-w-6xl mx-auto py-16 px-4">
        <h2 className="text-3xl font-semibold text-center mb-10">Koleksi Unggulan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[1, 2, 3].map((item) => (
            <div key={item} className="bg-white rounded-2xl shadow-md overflow-hidden">
              <img
                src={`https://via.placeholder.com/400x300?text=Pot+${item}`}
                alt={`Pot ${item}`}
                className="w-full h-60 object-cover"
              />
              <div className="p-4">
                <h3 className="text-xl font-bold mb-2">Pot Resin {item}</h3>
                <p className="text-sm text-stone-600 mb-2">Ukuran: 40x40cm</p>
                <a
                  href="#"
                  className="inline-block mt-2 px-4 py-2 bg-stone-800 text-white rounded-full hover:bg-stone-700"
                >
                  Pesan Sekarang
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-stone-200 py-16 px-4">
        <h2 className="text-3xl font-semibold text-center mb-10">Testimoni Pelanggan</h2>
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-2xl shadow">
            <p className="mb-4">"Potnya sangat estetik dan kuat! Sudah 1 tahun lebih tetap awet di halaman rumah."</p>
            <h4 className="font-bold">- Maria, Surabaya</h4>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow">
            <p className="mb-4">"Saya suka teksturnya, cocok sekali buat tanaman hias indoor saya."</p>
            <h4 className="font-bold">- Daniel, Jakarta</h4>
          </div>
        </div>
      </section>

      <section className="text-center py-16">
        <h2 className="text-3xl font-semibold mb-4">Hubungi Kami</h2>
        <p className="mb-6">Untuk pemesanan langsung atau menjadi reseller, silakan hubungi kami melalui:</p>
        <div className="space-y-2">
          <p>📞 WhatsApp: 085749219377</p>
          <p>📧 Email: dwijayalimestone@gmail.com</p>
          <p>📍 Instagram: @dwijayalimestone</p>
        </div>
      </section>

      <footer className="text-center text-sm py-4 bg-stone-100 border-t">
        &copy; 2025 Dwijaya Limestone. All rights reserved.
      </footer>
    </div>
  );
}
